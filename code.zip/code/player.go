// MATH 221 FALL 2016
//
// CLIENT for a BLACKJACK CARD-PLAYING SERVICE
//

package main

import (
	"cs221"
	"fmt"
	"strconv"
	"os"
	"strings"
)

func main() {
	hostname := "127.0.0.1"
	// Get the port number.
	port := 3000

	// Make a connection, getting "proxy" channels cout/cin.
	cout2, cin2, e := cs221.MakeConnection(hostname, port, "arc")
	if e != nil {
		fmt.Println(e.Error())
		os.Exit(1)
	}
	cout2 <- "LOOKUP aquote" + "\n"
	cout2 <- "\n"
	rep := <- cin2
	parts := strings.Split(rep, " ")
	hostname = parts[1]
	ports := strings.Replace(parts[2], "\n", "", -1)
	fmt.Println(ports)
	port, _ =  strconv.Atoi(ports)
	cout, cin, e := cs221.MakeConnection(hostname, port, "Quoter")

	if e != nil {
		fmt.Println(e.Error())
		os.Exit(1)
	}

	// Get the player's information. Send it to the server.
	fmt.Print("What's your name you dumb capitalist? ")
	s := ""
	fmt.Scanln(&s)
	cout <- s + "\n"
	cout <- "\n"
	
	done := false
	for !done {
		//
		// Get a response from the server. Output it.
		reply := <-cin
		fmt.Print(reply)

		// See if the gameplay is over.
		lines := cs221.Lines(reply)

		if lines[len(lines)-1] == "That's all you capitalist pig" {

			//
			// End the proxy's session by sending "".
			cout <- ""
			done = true

		} else {

			// Get a response from the user.
			var message string	
			fmt.Scanln(&message)

			// Forward it to the server.
			cout <- message + "\n"
			cout <- "\n"

		}
	}
}
