package main

import (
    "fmt"
    "net/http"
    "strings"
    "io/ioutil"
    "math/rand"
    "time"
    "cs221"
    "os"
    "strconv" 
)

// Global channel shared by all connection handlers.
// Used to report game results.
type report struct {
    player string
    result string
}
var creport chan report = make(chan report)
var insults []string = []string{"dumb cow", "stupid capitalist", "fat pig", "lenin", "Karl Marx's Dad", "Fat Banker", "Pot-Smoking Hippie", "Snotty Yuppie", "Stuck-up Yupster", "Arrogant Reedie", "Jim Fix", "Jay"}
func grabAnarchy() string{
  resp, err := http.Get("http://mentalanarchy.com/quotes.html")
  if err != nil {
    return "anarchy failed!"
  }
  defer resp.Body.Close()
  body, err := ioutil.ReadAll(resp.Body)
  if err != nil {
    return "anarchy failed!"
  }
  httpBody := string(body[:])
  regex := "<p><li>"
  splits := strings.Split(httpBody, regex)
  rand.Seed(time.Now().UnixNano())
  seed := rand.Intn(52)
  i := 0
  r := 0
  for i != len(splits){
    regex = "</li></p>"
    if strings.Contains(splits[i], regex) && !strings.Contains(splits[i], "<br>"){
      news := strings.Replace(splits[i], regex, "", -1) 
      if r == seed {
        return news
      }
      r += 1
    }
    i++
  }
  return "anarchy has failed!"
}

func handleAnarchy(out chan<- string, in <-chan string, info interface{}) {
  for {
    rand.Seed(time.Now().UnixNano())
    resp := cs221.HeadLine(<-in)
    var rep report = report{player:"A player has started talking to Jim Commie", result:""}
    creport <- rep
    fmt.Println("The capitalists name is", resp)
    out <- fmt.Sprintf("Hello fellow %s\n", insults[rand.Intn(10)])
    out <- "My name is Jim Commie\n"
    out <- "Has your day gone well?\n"
    out <- "\n"    
    resp = strings.Replace(cs221.HeadLine(<-in),"\n","", -1)
    for !(resp == "y" || resp == "n"){
      out <- "Sorry say that again?\n"
      out <- "\n"
      fmt.Println(resp)
      resp = strings.Replace(cs221.HeadLine(<-in), "\n","", -1)
    }
    rep = report{player:"Commie Jim is now talking to a", result: insults[rand.Intn(10)]}
    creport <- rep
    out <- "I really don't care how your stupid day has been\n"
    out <- "I'd like to tell you a little something fellow revolutionary\n"
    out <- "Would you like to hear it?\n"
    out <- "\n"
    resp = <-in
    if resp == "n" {
      out <- "Well I'll tell you anyway, comrade\n"
    } 
    out <- fmt.Sprintf("%s \n", grabAnarchy())
    for {
      out <- "Would you like another quote?\n"
      out <- "\n"
      resp = <-in
      out <- "I don't care what you say.\n"
      out <- "Here's another quote\n"
      out <- fmt.Sprintf("%s \n", grabAnarchy())
    }  
    
  } 
}

func addtoReg(args []string) {
  hostname := "127.0.0.1"
  port := 3000
 
  cout2, _, e := cs221.MakeConnection(hostname, port, "arc")
  if e != nil {
   fmt.Println(e.Error())
    os.Exit(1)
  }
  cout2 <- "ADD " + "aquote " + args[1] +" "+ args[2] + "\n"
  cout2 <- "\n"
}

func main() {
  if len(os.Args) < 3 {
    fmt.Printf("Error: too few command-line arguments.\n")
    fmt.Printf("usage: go run aquote.go <host> <port>\n")
    os.Exit(0)
  }

  addtoReg(os.Args)
  fmt.Println("Added service to registry.")
  hostname := os.Args[1]
  port,_ := strconv.Atoi(os.Args[2])

    // Run a reporting go routine.
  go func() {
    for {
      r := <-creport 
      fmt.Printf("REPORT: %s %s\n",r.player,r.result) 
     }
  }()

    // Loop, accepting and handling client connections.
  e := cs221.HandleConnections(hostname, port, handleAnarchy, "AnarchyBot", nil)

    // This code will only be reached when the server
    // is shutting down, or when an error occurs.
    //
  if e != nil {
    fmt.Println(e.Error())
    os.Exit(0)
  }

}
