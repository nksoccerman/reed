package main

import (
	"cs221"
	"strings"
	"os"
	"fmt"
	"strconv"
)
	

type transaction struct {
        request string
        replyChan chan<- string
}

func handleInteract(request string, dat []string) string{
	parts := strings.Split(request, " ")
	if parts[0] ==  "LOOKUP" {
		tofind := parts[1] 
		x := "Can't find entry..."
		i := 0
		for i < len(dat) {
			if strings.Contains(dat[i], tofind) {
				x = dat[i]
				break
			}
			i++
		}
		return x
	} else if parts[0] == "ADD" {
		toadd := strings.Split(request, "ADD ")[1]
		i := 0
		for i < len(dat) {
			i++
			if dat[i] == "" {
				break
			} 
		}
		dat[i-1] = toadd
		return "Entry Added"
	} else if parts[0] == "REMOVE"{
		toremove := parts[1]
		x := "Can't find entry..."
		i := 0
		for i < len(dat) {
			if strings.Contains(dat[i], toremove){	
				dat[i] = ""
				x = "Entry Removed."
				break
			}
			i++
		}
		return x
	} else {
		return "Please enter LOOKUP, ADD, or REMOVE"
	}
}

func startReg(dat []string) chan transaction {
        tc := make(chan transaction)
        go func () {
                for t := range tc {
                        r := handleInteract(t.request,dat)
			t.replyChan <- r + "\n"
			t.replyChan <- "\n"
			fmt.Printf("Replying to client: %s\n", r)
                }
        } ()
        return tc
}

func handleConn(cout chan<- string, cin <-chan string, tc chan transaction) {
        fmt.Println("A client has connected.")

        done := false
        for !done {
                r := (<-cin)
                if r != "" {
                        tc <- transaction{request:cs221.HeadLine(r),replyChan:cout}
                } else {
                        done = true
                }
        }

        fmt.Println("Client disconnected.")
}

func main() {
  if len(os.Args) < 3 {
    fmt.Printf("Error: too few command-line arguments.\n")
    fmt.Printf("usage: go run aquote.go <host> <port>\n")
    os.Exit(0)
  }
  hostname := os.Args[1]
  port,_ := strconv.Atoi(os.Args[2])

  clients, _ := cs221.HandleAllConnections(hostname, port) 
  fmt.Println("Bringing up arcade service")
  a := make([]string, 10)
  b := startReg(a)

  for {
    conn := (<-clients)
    go handleConn(conn.Out, conn.In, b)
  }
}
